# Asset Management Assistant — Backend 1: ReAct Agent

An AI-powered assistant that answers natural-language questions about XYZ
Technologies' IT assets. **Backend 1** implements a hand-rolled **ReAct agent**
(Reason → Act → Observe) over **Ollama Cloud** native function calling.

> This is the first of three backends. Backends 2 (multi-agent supervisor) and 3
> (semantic routing) share the same `shared/` layer and plug into one Streamlit UI.

## Architecture

```
User ──HTTP──▶ FastAPI (/chat)
                   │
                   ▼
             ReAct Agent loop ──▶ Ollama Cloud (gemma4:31b-cloud)
                   │   ▲                 │ native tool_calls
                   │   └─ Observation ───┘
                   ▼
             Tool dispatcher (Pydantic-validated)
                   │
                   ▼
             Read-only SQLite (safe_execute guard)
```

The LLM never writes SQL. It selects among five typed tools; each builds a
parameterized, read-only query. The loop runs Thought → Action → Observation
until the model returns a final text answer (bounded by `AGENT_MAX_STEPS`).

## Layout

```
shared/                     # reused by all three backends
  config.py                 # pydantic-settings; every knob is env-overridable
  db/database.py            # read-only safe_execute guard
  db/init_db.py             # async CSV → SQLite seeder
  db/schema.sql             # assets table + indices
  llm/ollama_client.py      # AsyncClient + concurrency semaphore
backend_react/
  core/tools.py             # 5 tools + Pydantic schemas + registry
  core/agent.py             # the ReAct loop
  core/prompts.py           # system prompt
  api/routes.py             # /chat, /chat/stream, /health
  api/schemas.py            # request/response models
  auth/security.py          # bearer API-key dependency
  main.py                   # FastAPI app
data/assets_seed.csv        # the 21 sample assets
```

## Setup

```bash
# 1. Install
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
#   edit .env: set OLLAMA_API_KEY (required) and APP_API_KEY

# 3. Seed the database
python -m shared.db.init_db

# 4. Run
uvicorn backend_react.main:app --reload --port 8001
```

Interactive API docs: http://localhost:8001/docs

## Usage

```bash
curl -X POST http://localhost:8001/chat \
  -H "Authorization: Bearer dev-local-key-change-me" \
  -H "Content-Type: application/json" \
  -d '{"message": "Who else has the same laptop as Amit Kumar (AST1002)?"}'
```

Every `/chat` response includes a `trace` array showing each tool the agent
called and what it observed — the agentic reasoning made visible.

## What the data supports

The dataset has six fields: asset code, name/model, category, employee, location,
purchase date. There is **no manager, floor, or availability** column, so the
assistant answers those honestly ("the data doesn't contain that") rather than
inventing values. The required behaviours map to real data as:

| Requirement | Example query | Tool(s) |
|---|---|---|
| Lookup by code | "Where is AST1002?" | `lookup_asset_by_code` |
| Natural language | "List all laptops in Bangalore" | `search_assets` |
| Multi-step reasoning | "Who else has the same laptop as Amit Kumar (AST1002)?" | `find_related_by_model` |
| Follow-up context | "…and in Chennai?" | history-aware loop |
| Recommendation | "Find a MacBook in Bangalore" | `recommend_assets` |

## Security

- **Read-only DB connection** (`mode=ro` URI) — writes are physically impossible.
- **`safe_execute` guard** — rejects any non-SELECT, blocks statement stacking,
  enforces a row cap.
- **No LLM-authored SQL** — the model only fills validated tool parameters.
- **Bearer auth** on all agent endpoints.

## Configuration highlights

| Env var | Default | Purpose |
|---|---|---|
| `OLLAMA_API_KEY` | *(required)* | Cloud key; never hardcoded |
| `LLM_MODEL` | `gemma4:31b-cloud` | Swap models in one line |
| `LLM_MAX_CONCURRENCY` | `1` | Free-tier cloud limit; raise to 3/10 for Pro/Max |
| `AGENT_MAX_STEPS` | `6` | Max reasoning iterations |
| `AUTH_MODE` | `api_key` | Switch to `jwt` without touching routes |
```
